run the following in the current folder

doxygen doxy.config

assumes that dot tool is installed and available from path
